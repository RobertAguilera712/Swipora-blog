from pymdownx import emoji
import re

from plugins import english_highlighter


MARKDOWN = {
    "extensions": [
        "pymdownx.mark",
        "pymdownx.smartsymbols",
        "pymdownx.tilde",
        "pymdownx.saneheaders",
        "pymdownx.keys",
        "pymdownx.inlinehilite",
        "pymdownx.emoji",
        "pymdownx.snippets",
        "pymdownx.extra",
        "pymdownx.arithmatex",
    ],
    "extension_configs": {
        "pymdownx.emoji": {"emoji_generator": emoji.to_png_sprite},
        "pymdownx.extra": {
            "markdown.extensions.attr_list": {}
        },
        "pymdownx.arithmatex": {
            "generic": True
        },
        'hl_extension': {},
    },
}

AUTHOR = "Roberto Aguilera"
SITENAME = "Swipora"
SITESUBTITLE = "Aprende inglés de forma inteligente"
SITEURL = ''
THEME = "./themes/swipora_theme"

PATH = "content"

TIMEZONE = "America/Mexico_City"

DEFAULT_LANG = "es"

# Feed generation is usually not desired when developing
FEED_ALL_ATOM = None
CATEGORY_FEED_ATOM = None
TRANSLATION_FEED_ATOM = None
AUTHOR_FEED_ATOM = None
AUTHOR_FEED_RSS = None

AUTHOR_ABOUT = "Soy un ingeniero de software apasionado por compartir conocimiento y crear soluciones digitales. Cuento con amplia experiencia en el desarrollo de aplicaciones móviles, web y de escritorio, diseñando todo tipo de software que impulse y se adapte a tu negocio."


# Blogroll
LINKS = (
    ("Pelican", "https://getpelican.com/"),
    ("Python.org", "https://www.python.org/"),
    ("Jinja2", "https://palletsprojects.com/p/jinja/"),
    ("You can modify those links in your config file", "#"),
)

# Social widget
SOCIAL = (
    ("You can add links in your config file", "#"),
    ("Another social link", "#"),
)

DEFAULT_PAGINATION = 10

DISPLAY_PAGES_ON_MENU = True

SUMMARY_MAX_PARAGRAPHS = 1

# Enable Pygments for syntax highlighting
PYGMENTS_RST_OPTIONS = {"class": "highlight"}
# Optional: Use CSS classes instead of inline styles
PYGMENTS_USE_CLASSES = True

LIQUID_TAGS = ["img", "literal", "video", "youtube", "vimeo", "include_code"]

STATIC_PATHS = ["images",]

ARITCLE_URL = "blog/{slug}.html"
ARITCLE_SAVE_AS = "blog/{slug}.html"

INDEX_SAVE_AS = "blog/index.html"

# Uncomment following line if you want document-relative URLs when developing
# RELATIVE_URLS = True


