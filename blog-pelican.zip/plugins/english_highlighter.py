import re
from markdown.extensions import Extension
from markdown.inlinepatterns import InlineProcessor
import xml.etree.ElementTree as ET

# 1. Your exact highlighting logic adapted for raw strings
def highlight_question_html(text):
    text = re.sub(r'\s*\?\s*$', '', text.strip())
    
    wh_pattern = r'\b(What kind of|What|Who|Where|When|Why|How|Which|Whose)\b'
    be_pattern = r'\b(are|is|am|was|were)\b'
    auxiliaries_pattern = r'\b(going to|did|do|does|have|has)\b'
    pronoun_pattern = r'\b(you|i|he|she|it|we|they|u)\b'
    
    verb_list = (
        r'eat|ate|eaten|eating|drink|drank|drunk|drinking|read|reading|write|wrote|written|writing|'
        r'watch|watched|watching|call|called|calling|take|took|taken|taking|give|gave|given|giving|'
        r'buy|bought|buying|sell|sold|selling|open|opened|opening|close|closed|closing|listen to|'
        r'listened to|listening to|go|went|gone|going|come|came|coming|sit|sat|sitting|stand|stood|'
        r'standing|cook|cooked|cooking|ask|asked|asking|play|played|playing|tell|told|telling|'
        r'work|worked|working|repair|repaired|repairing|study|studied|studying|bring|brought|'
        r'bringing|pick up|picked up|picking up|put|putting|meet|met|meeting|drive|drove|driven|'
        r'driving|dance|danced|dancing|want|wanted|wanting|know|knew|known|knowing|teach|taught|'
        r'teaching|visit|visited|visiting|think|thought|thinking|like|liked|liking|plan|planned|'
        r'planning|travel|traveled|traveling|talk|talked|talking|need|needed|needing|make|made|'
        r'making|do|did|done|doing|sing|sang|sung|singing|walk|walked|walking|feel|felt|feeling|'
        r'cut|cutting|have|had|having|sleep|slept|sleeping|send|sent|sending|run|ran|running|'
        r'see|saw|seen|seeing|wear|wore|worn|wearing|lie|lied|lying|argue|argued|arguing|'
        r'help|helped|helping|pay|paid|paying'
    )
    
    text = re.sub(wh_pattern, r'<span class="hl-teal">\1</span>', text, flags=re.IGNORECASE)
    text = re.sub(be_pattern, r'<span class="hl-pink">\1</span>', text, flags=re.IGNORECASE)
    text = re.sub(auxiliaries_pattern, r'<span class="hl-red">\1</span>', text, flags=re.IGNORECASE)
    text = re.sub(pronoun_pattern, r'<span class="hl-green">\1</span>', text, flags=re.IGNORECASE)
    
    protection_pattern = r'<span class="[^"]+">[^<]+</span>'
    final_verb_pattern = rf'{protection_pattern}|(?:\b({verb_list})\b)'
    
    text = re.sub(
        final_verb_pattern, 
        lambda m: m.group(0) if m.group(1) is None else f'<span class="hl-blue">{m.group(1)}</span>', 
        text, 
        flags=re.IGNORECASE
    )
    return f"{text}?"

# 2. Define the Markdown Inline Processor
class HighlightPattern(InlineProcessor):
    def handleMatch(self, m, data):
        # Create a container element (a span) for the parsed text
        el = ET.Element('span')
        el.set('class', 'highlighted-english')
        
        # Get the targeted sentence inside the ?? triggers
        raw_sentence = m.group(1)
        
        # Process the sentence through your highlighter
        html_output = highlight_question_html(raw_sentence)
        
        # Inject the resulting HTML safely into Python-Markdown's tree
        el.text = html_output
        return el, m.start(0), m.end(0)

# 3. Register the Extension
class QuestionHighlightExtension(Extension):
    def extendMarkdown(self, md):
        # Look for text wrapped inside ?? sentence ??
        # Example: ??What are you eating??
        RE_PATTERN = r'\?\?([^\?]+)\?\?'
        md.inlinePatterns.register(HighlightPattern(RE_PATTERN, md), 'highlighted-english', 175)

def makeExtension(**kwargs):
    return QuestionHighlightExtension(**kwargs)
